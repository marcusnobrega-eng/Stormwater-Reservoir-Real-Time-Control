%% Watershed Finite-Difference Scheme Model
% Developer: Marcus Nobrega
% 4/23/2021
% Goal: Define a Model that Calculates the flow in the Outlet of a
% Watershed in a Matrix Fashion
% Observation: This function calculates
% d(k+1) = d(k) + T*(i(k) + (qin(k) - qout(k)) - ETP(k) - qinf(k))
% for one time-step, or from k to k + 1

function [F_d,d_t,flow_t] = wshed_matrix(d_0,h_0,inflows,time_step,Inflow_Matrix,Direction_Matrix,i_0,ksat,psi,dtheta,I_0,Lambda,Delta_x,Delta_y,ETP)
    % Faster way    
    % Evaporation Estimative
    % ETP = 2; % mm/day
    % Solving the discretized water balance in each cell
    % d(k+1) = d(k) + T*(i(k) + (qin - qout) - inf)
    if max(inflows) <= 1e-2 % mm
        % No need for matrix multiplication
        d_t = d_0 + time_step/3600*(i_0 - min(i_0,ksat.*(1 + ((psi + d_0).*dtheta)./I_0)));   
    else
        d_t = d_0 + time_step/3600*(Direction_Matrix*inflows + i_0 - min(Inflow_Matrix*inflows + i_0,ksat.*(1 + ((psi + d_0).*dtheta)./I_0))); % took out d_t/time_step
    end
    % Calculate the Accumulated Inflow Depth F_d
    F_d = max(I_0 + (i_0*time_step/3600 + d_0 - d_t - ETP/24/3600*time_step),5); % Stored depth in mm for (k+1); (assuming a min of 5 mm)   
    % Calculating the Outflow from each cell. This outflow becomes the
    % inflows for the next time-step
    flow_t = non_lin_reservoir(Lambda,d_t,h_0,Delta_x,Delta_y); % flow_t = flow(k+1) (outflow from each cell)

end