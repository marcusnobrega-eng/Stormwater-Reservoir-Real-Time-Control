%% Reservoir Dynamics - Main Script
% 8/1/2021
% Developer: Marcus Nobrega
% Goal - Develop a linearized state-space represenntation of the Reservoir
% Dynamics
%% Mathematical Model - Non-linear Reservoir Dynamics
% dS/dt = Qin(t) - Qout(t) ; Qin is the inflow, Qout is the outflow
% dS/dt*1/(A(h)) = (Qin(t) - Qout(t))/A(h)
% dh/dt = (1/A(h))*(Qin(t) - Qout(t)  eq. (1)
% Qout(t) = Cd*Ao*u*sqrt(2*g*(h(t) - hi(t))) + Cds*Lefs*(h(t) - hs)^1.5; 
% h(t) is the water level in the reserovir, hi(t) is the outlet water level
% Cd,Ao are orifice parameters and Cd, Lef and hs are spillway paramters
% We can write eq. (1), such that:
% dh/dt = hdot = (1/A(h))*(Qin(t) + Ko*u*sqrt(h(t) - ho(t)) + max(Ks*(h(t) - hs))^(3/2)) eq.(2)
% where Ko = Cd*Ao and Ao can be a function such that Ao = pi()*D^2/4 for a
% circular orifice and Ks = Cds*Lef
%% Control Variable
% u -> [0 1], where 0 means a closed valve and 1 an fully openned valve
%% Linearization
% We can use a 1st order Taylor approximation to linearize eq. (2) around
% operation points (h0, u0), such that:
% hdot = f(x,u) = f'x(xeq,ueq)*(x - x0) + f'u(xeq,ueq)*(u - ueq) + f(xeq,yeq),
% where f'x is the Jacobian of hdot with respect to x and f'u with respect
% to u
% We can write the following equation: (x -- h)
% hdot = alfa*(h - heq) + beta*(u - ueq) + gama eq. (3) ; where alfa and beta are
% Jacobians and gama are operation point initial condition
%% Discretization
% f(x,u) = hdot(x,u) => h(k + 1)-h(k) = T*(alfa(h(k) - heq)+beta*(u(k) - ueq)+gama)
% h(k+1) = h(k) + T*alfa*h(k) + T*beta*u(k) + (T*gama - T*alfa*heq - T*beta*ueq)
% Finally
% h(k+1) = (1 + T*alfa)*h(k) + (T*beta)*u(k) + fi, fi = T*(gama - alfa - beta) 
% h(k+1) = A*h(k) + B*u(k) + fi; 

%% Parameters
h_t_t = 0;
h_t = 0;
clc
% Equilibrium Points
h_eq = h_t_t; % m
% Initial Values
u_eq = u(1); % boolean (0-1), 1 is fully opened, 0 is fully closed
g = 9.81; % m/s^2
T = time_step; % seconds
% Reservoir Area
[Area_Function] = reservoir_area(0) ; % A = f(h) (handle) Function of h (to change, is required to change the function)
% Orifice Parameters
Cd = 0.68;
orifice_height = 0; % m from the bottom
number_of_orifices = 2;
%   Circular
flag_c = 1; % 1 if it is circular, 0 if not used
D = 1.2; % m 
Aoc = pi()*D^2/4*number_of_orifices;
%   Rectangular
flag_r = 0; % 1 if it is rectangular, 0 if not used
l = 1;
b = 1.2;
Aor = l*b*number_of_orifices;
if ((flag_c == 1) && (flag_r == 1)) 
    error('Please choose only one type of orifice')
elseif (flag_c == 1)    
    D_h = D; % circular
    Ao = Aoc;
else
    D_h = 4*(l*b)/(2*(l+b)); % rectangular
    Ao = Aor;
end
hmin = 0.2; % minimum relative water depth
h_flow = max(hmin*D_h,orifice_height);
% Spillway Parameters
Cds = 2.10;
Lef = 3; % m
hs = 5.5; % m
% Inflow
Qin = out_w; % m3/s
% Reservoir Porosity
porosity = 1;
% Flow Equation
outflow_eq = @(Ko,Ks,h,hs,ho,u_eq) (Ko.*u_eq.*sqrt(max(h - h_flow,0)) + max(Ks.*(h - hs),0).^(3/2));
out_r = zeros(n_steps,1);
%% Calculating Constants
Ko = Cd*Ao*sqrt(2*g); Ks = Cds*Lef;
%% Symbolic Alfa and Beta Matrices
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); %  maybe we dont need
%% Determining Jacobian Matrices
Qin_t = Qin(1);
i_0 = i_reservoir(1,1);
[alfa,beta] = alfabeta_matrices(Qin_t,Ko,u_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);% Calculating gama
gama = (1/(Area_Function(h_eq)*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,u_eq))) + i_0/1000/3600; % Adding Rainfall
gama(isnan(gama))=0;
%% Discretizing the System
A = (1 + T*alfa);
B = (T*beta);
fi = (T*gama - T*alfa*h_eq - T*beta*u_eq);
% h(k+1) = A*h(k) + B*u + fi(k)
h = zeros(n_steps,1) ; h(1,1) = h_t;
Qin_t = Qin(1);
%u = repmat(1,[steps,1]); % Fully Opened
%% Noise
average = 0;
variance = 0;
%% Flow Routing - Main Script
for k = 1:(n_steps-1)    
    % Generate a Gaussian Noise
    [g_noise] = gaussian_noise_generator(variance,average);    
    h(k+1) = max(A*h(k) + B*u(k,1) + fi + g_noise ,0); % Constraint to make water level positive
    Qin_t = Qin(k+1);
    i_0 = i_reservoir(k+1,1); % Initial Rainfall for the next time-step
    h_t = h(k);
    % New Operation Point
    h_eq = h(k);
    u_eq = u(k);
    % Jacobians
    [alfa,beta] = alfabeta_matrices(Qin_t,Ko,u_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);   
    out_r(k,1) = outflow_eq(Ko,Ks,h_eq,hs,h_flow,u_eq);
    % Calculating gama
    gama = (1/(Area_Function(h_eq)*porosity)*(Qin_t - out_r(k,1)) + i_0/1000/3600);
    gama(isnan(gama))=0;
    % New State-Space
    A = (1 + T*alfa);
    B = (T*beta);
    fi = (T*gama - T*alfa*h_eq - T*beta*u_eq);
end
x_r = h;

