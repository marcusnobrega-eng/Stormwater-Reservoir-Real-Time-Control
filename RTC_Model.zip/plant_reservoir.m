%% Reservoir Dynamics - Main Script
% 4/25/2021
% Note - I added rainfall in the area of the reservoir
% Developer: Marcus Nobrega
% Goal - Develop a linearized state-space represenntation of the Reservoir
% Dynamics
function [h_r,Qout_r] = plant_reservoir(Qout_w,time_step,u,h_t,ur_eq)
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon average variance
%% Mathematical Model - Non-linear Reservoir Dynamics
% dS/dt = Qin(t) - Qout(t) ; Qin is the inflow, Qout is the outflow
% dS/dt*1/(A(h)) = (Qin(t) - Qout(t))/A(h)
% dh/dt = (1/A(h))*(Qin(t) - Qout(t)  eq. (1)
% Qout(t) = Cd*Ao*u*sqrt(2*g*(h(t) - hi(t))) + Cds*Lefs*(h(t) - hs)^1.5; 
% h(t) is the water level in the reserovir, hi(t) is the outlet water level
% Cd,Ao are orifice parameters and Cd, Lef and hs are spillway paramters
% We can write eq. (1), such that:
% dh/dt = hdot = (1/A(h))*(Qin(t) + Ko*u*sqrt(h(t) - ho(t)) + max(Ks*(h(t) - hs))^(3/2)) eq.(2)
% where Ko = Cd*Ao and Ao can be a function such that Ao = pi()*D^2/4 for a
% circular orifice and Ks = Cds*Lef
%% Control Variable
% u -> [0 1], where 0 means a closed valve and 1 an fully openned valve
%% Linearization
% We can use a 1st order Taylor approximation to linearize eq. (2) around
% operation points (h0, u0), such that:
% hdot = f(x,u) = f'x(xeq,ueq)*(x - x0) + f'u(xeq,ueq)*(u - ueq) + f(xeq,yeq),
% where f'x is the Jacobian of hdot with respect to x and f'u with respect
% to u
% We can write the following equation: (x -- h)
% hdot = alfa*(h - heq) + beta*(u - ueq) + gama eq. (3) ; where alfa and beta are
% Jacobians and gama are operation point initial condition
%% Discretization
% f(x,u) = hdot(x,u) => h(k + 1)-h(k) = T*(alfa(h(k) - heq)+beta*(u(k) - ueq)+gama)
% h(k+1) = h(k) + T*alfa*h(k) + T*beta*u(k) + (T*gama - T*alfa*heq - T*beta*ueq)
% Finally
% h(k+1) = (1 + T*alfa)*h(k) + (T*beta)*u(k) + fi, fi = T*(gama - alfa - beta) 
% h(k+1) = A*h(k) + B*u(k) + fi; 

%% Reservoir Parameters
% Equilibrium Points
h_eq = h_r_t; % m
% ur_eq = 1; % boolean
% Initial Values
% h_r_t = 0; % Initial Water Level in the Reservoir (m)
ur_eq = ur_eq_t; % boolean (0-1), 1 is fully opened, 0 is fully closed
g = 9.81; % m/s^2
T = time_step; % seconds
% Reservoir Area
[Area_Function] = reservoir_area(0) ; % A = f(h) (handle) Function of h (to change, is required to change the function)
% Orifice Parameters
Cd = 0.68;
number_of_orifices = 2;
%   Circular
flag_c = 1; % 1 if it is circular, 0 if not used
D = 1.2; % m 
Aoc = pi()*D^2/4*number_of_orifices;
%   Rectangular
flag_r = 0; % 1 if it is rectangular, 0 if not used
l = 1;
b = 1.2;
Aor = l*b*number_of_orifices;
if ((flag_c == 1) && (flag_r == 1)) 
    error('Please choose only one type of orifice')
elseif (flag_c == 1)    
    D_h = D; % circular
    Ao = Aoc;
else
    D_h = 4*(l*b)/(2*(l+b)); % rectangular
    Ao = Aor;
end
hmin = 0.2; % minimum relative water depth
orifice_height = 0; % m from the bottom
h_flow = max(hmin*D_h,orifice_height);

% Spillway Parameters
Cds = 2.10;
Lef = 3; % m
hs = 5.5; % m
% Inflow
Qin = Qout_w_horizon; % m3/s
% Reservoir Porosity
porosity = 1;
% Flow Equation
outflow_eq = @(Ko,Ks,h,hs,ho,ur_eq) (Ko.*ur_eq.*sqrt(max(h - h_flow,0)) + max(Ks.*(h - hs),0).^(3/2)); % Reservoir Outflow Function
%% Calculating Constants
Ko = Cd*Ao*sqrt(2*g); Ks = Cds*Lef; % Reservoir Constants
%% Symbolic Alfa and Beta Matrices
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); %  maybe we dont need
%% Determining Jacobian Matrices
Qin_t = Qin(1);
i_0 = i_reservoir_horizon(1,1); %%%% fix it here
[alfa_tilde,beta_tilde] = alfabeta_matrices(Qin_t,Ko,ur_eq,h_eq,h_flow,Ks,hs,h_r_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);% Calculating alfa and beta
gama_tilde = (1/(Area_Function(h_eq)*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,ur_eq))) + i_0/1000/3600; % Adding Net Rainfall
gama_tilde(isnan(gama_tilde))=0;
%% Discretizing the System
A = (1 + T*alfa_tilde);
B = (T*beta_tilde);
fi = (T*gama_tilde - T*alfa_tilde*h_eq - T*beta_tilde*ur_eq);
% h(k+1) = A*h(k) + B*u + fi(k)
h = zeros(steps_horizon,1) ; h(1,1) = h_r_t;
%% Main for Loop
for k = 1:(steps_horizon-1)    
    k/steps_horizon*100;
    [g_noise] = gaussian_noise_generator(variance,average);
    h(k+1) = max(A*h(k) + B*u(k,1) + fi + g_noise ,0); % Constraint to make water level positive
    Qin_t = Qin(k+1);
    i_0 = i_reservoir_horizon(k,1); % Initial Rainfall for the next time-step
    h_t = h(k);
    % New Operation Point
    h_eq = h(k);
    ur_eq = u(k);

    % Jacobians
    [alfa_tilde,beta_tilde] = alfabeta_matrices(Qin_t,Ko,ur_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,D_h);   
    % Calculating gama_tilde
    gama_tilde = (1/(Area_Function(h_eq)*porosity)*(Qin_t - outflow_eq(Ko,Ks,h_eq,hs,h_flow,ur_eq))) + i_0/1000/3600;
    gama_tilde(isnan(gama_tilde))=0;
    % New State-Space
    A = (1 + T*alfa_tilde);
    B = (T*beta_tilde);
    fi = (T*gama_tilde - T*alfa_tilde*h_eq - T*beta_tilde*ur_eq);
end
Qout_r = outflow_eq(Ko,Ks,h,hs,h_flow,u);
h_r = h;