%% Numerical Jacobians for the Channel
% 8/1/2021
% Developer - Marcus Nobrega
% Goal: Numerically assesses the Jacobians and Define the Matrices
% representing the channel dynamics
% h_dot = f(h,t) = f'h(h0)(h(t) - h0) + h_dot(h0,t)
% f'h(h0) = gradient(f,h)(h0)
function [gradient_c] = gradient_channel(dir_matrix,x_cells,A_slope,B_slope,roughness,h_0_c,cell_area)
cell_area_ = cell_area;
h = h_0_c;
Z_ = dir_matrix;
b = x_cells;
As_ = A_slope;
Bs_ = B_slope;
n_ = roughness;
% To estimate this function below, we used the script
% (symbolic_jacobians_channel). We also added .*, ./ and .^ mathematical
% symbols to accurately represent elementwise operations
%%% Only valid for rectangular Channels. Please use the symbolic solution
%%% for other cross sections and change the corresponding equation given
%%% below
gradient_c = ((Z_.*b.*(Bs_ + As_.*h).^(1/2).*((b.*h)./(b + 2.*h)).^(2/3))./n_ + (As_.*Z_.*b.*h.*((b.*h)./(b + 2.*h)).^(2/3))./(2.*n_.*(Bs_ + As_.*h).^(1/2)) + (2.*Z_.*b.*h.*(b./(b + 2.*h) - (2.*b.*h)./(b + 2.*h).^2).*(Bs_ + As_.*h).^(1/2))./(3.*n_.*((b.*h)./(b + 2.*h)).^(1/3)))./cell_area_;
gradient_c(isnan(gradient_c)) = 0;
end