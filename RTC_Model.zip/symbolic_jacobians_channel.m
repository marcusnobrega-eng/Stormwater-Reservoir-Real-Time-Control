%% Channel Symbolic Jacobian Matrices
% 8/1/2021
% Developer: Marcus Nobrega
% Goal - Define symbolic jacobian matrices for a given system of equations
function [h_dot_channel,gradient_h] = symbolic_jacobians_channel(wet_area,h_radius_23)
syms h_ cell_area_ Z_ n_ A_ Rh_ As_ Bs_ w_ b
% h is a vector with the water surface elevation in each reach
% The water level differential equation in each cell of a 1-D channel is a
% function of the area,
% h_dot = 1/cell_area*(Z*(1/n*A(h)*Rh(h)^(2/3)*(As*h +B)^(1/2) + w)
h_dot_channel = 1/cell_area_*(Z_*(1/n_*wet_area*h_radius_23*(As_*h + Bs_)^(1/2)) + w_);
gradient_h = gradient(h_dot_channel,h);
end
% h(k+1) = h(k) + T(gradient(h0)*(h - h0) + hdot(h0))