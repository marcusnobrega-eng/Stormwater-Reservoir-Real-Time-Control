%% LQR Integrator Design
% Marcus Nobrega Gomes Junior
% 6/19/2021
% Model Working Fine
% Objective: Define the parameters for the LQI 
function [K,poles,A_aug,B_aug,C_aug,D_aug,A_augc,B_augc,C_augc,D_augc] = LQI_matrices(nx,ny,nu,A_res,B_res,C_res,D_res,n_steps,time_step,alfa,beta)
%% Construct the augmented dynamics
% Continuous System
% alfa is the gradient with respect to h and beta with respect with u
A_ct = alfa;
B_ct = beta;
C_ct = C_res;
D_ct = D_res;

% Create a continuous-time system
cont_sys = ss(A_ct,B_ct,C_ct,D_ct);
% Create an Augmented Continuous System
A_augc = [A_ct zeros(nx,ny); -C_ct zeros(ny,ny)];
B_augc = [B_ct ; -D_ct];
C_augc = [C_ct zeros(ny,ny)];
D_augc = D_ct;
augmented_cont_sys = ss(A_augc, B_augc, C_augc, D_augc);
% Discretize the Augmented Continous System
disc_sys = c2d(augmented_cont_sys,time_step);
A_aug = disc_sys.A;
B_aug = disc_sys.B;
C_aug = disc_sys.C;
D_aug = disc_sys.D;
K = zeros(nu,nx+ny);
poles = zeros(size(A_aug,1),1);
if (rank(ctrb(A_aug, B_aug)) ~= size(A_aug,1)) %|| (rank(obsv(A_aug,C_aug)) ~= size(A_aug,1))
    %error('Some nodes are uncontrollable');
else
%% Construct the Weighting Matrices
Qx = 1*C_aug'*C_aug; % 100
Qz = 1.5*10^3*blkdiag(zeros(size(C_res'*C_res)),eye(ny)); % 10^5
% Q = Qx + Qz + factor*eye(n+p);
factor = 1e-6;
Q = Qx + Qz + factor*eye(nx+ny);
    if issymmetric(Q)
    else
        error('Q is not symetric')
    end
z = eig(Q);
    if all(z > 0)
    else
        error('Q is not positive definite')
    end
R = 10^2*diag(ones(nx,1)) + factor;
N = 0*(eye(nx+ny,nu));
%% Output
% K = dlqr(A_aug,B_aug,Q,R); Depending on the discretization, this result
% can be poorly discretized
K = lqr(A_augc,B_augc,Q,R,N);
poles = eig(A_aug - B_aug*K);
end