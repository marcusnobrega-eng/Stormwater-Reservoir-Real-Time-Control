%% Static Control Rules
% 5/4/2021
% Developer: Marcus NobreOptim
% Goal - Apply static control rules to the reservoir and channel dynamics

%% Optimal Control Values
% out_c_Optim= out_c;
% out_r_final = out_r;
% h_r_final = h;
% h_c_Optim = h_c;
% u = u;
time_plot = [0:time_step:(n_steps-1)*time_step]/60/60; % hours
%% 1.0 - Passive Control
clear u out_c our_r x_r h_c
u_passive = 1;
for i=1:n_steps
    u(i,1) = u_passive;
end
reservoir_dynamics_script
channel_routing_script
out_c_passive= out_c;
out_r_passive = out_r;
h_r_passive = x_r;
h_c_passive = h_c;
u_passive = u;
%% 2.0 - Detention Control
clear u out_c our_r x_r h_c
td = 6*60; % min - Time to start releasing water
u_DC = 1; % Valve opening after td
E = 2; % mm/day
% for i=1:n_steps
%     if i_reservoir(i) + E/24 == 0 
%         count = i*time_step/60 - t_end; % minutes
%         if count>td
%             u(i,1) = u_DC;
%         else
%             u(i,1) = 0;
%         end
%     else
%         u(i,1) = 0;
%         t_end = i*time_step/60;% ; minutes;
%     end
% end

for i=1:n_steps
        count = i*time_step/60/60;
        if count> 12 + td/60
            u(i,1) = u_DC;
        else
            u(i,1) = 0;
        end
end

reservoir_dynamics_script
channel_routing_script
out_c_DC= out_c;
idx = find(u == 0);
out_r_DC = out_r;
out_c_DC(idx) = 0;
h_r_DC = x_r;
h_c_DC = h_c;
u_DC = u;

% subplot(4,1,1); plot(h_r_DC); subplot(4,1,2); plot(i_reservoir); subplot(4,1,3); plot(out_r_DC); hold on; plot(out_w); subplot(4,1,4); plot(u_DC);
%%%% Previous algorithm %%%%
% td = 6*60; % min - Time to start releasing water
% event_duration = 12*60; % min
% u_DC = 1; % Valve opening after td
% for i=1:n_steps
%     if i < ((event_duration+td))*60/time_step
%         u(i,1) = 0;
%     else
%         u(i,1) = u_DC;
%     end
% end
% reservoir_dynamics_script
% channel_routing_script
% out_c_DC= outflow(h_c(n_cells,:),x_cells(n_cells),roughness(n_cells),slope(n_cells));
% idx = find(u == 0);
% out_r_DC = out_r;
% out_c_DC(idx) = 0;
% h_r_DC = x_r;
% h_c_DC = h_c;
% u_DC = u;
%% 3.0 - On/Off Control
clear u out_c our_r x_r h_c
hc_of = 3; % Critical Water Level to Open the Valve
reservoir_dynamics_on_off % On-Off Control Strategy
channel_routing_script
out_c_of= out_c;
out_r_of = out_r;
idx = find(u == 0);
out_c_DC(idx) = 0;
h_r_of = x_r;
h_c_of = h_c;
u_of = u;

       
%% Plotting Results
% Tank Hydrographs
subplot(2,2,1)
set(gcf,'units','inches','position',[5,0,7,14])
plot(time_plot,our_r_final,'red','LineWidth',1)
hold on
plot(time_plot,out_r_passive,'blue','LineWidth',1)
hold on
plot(time_plot,out_r_DC,'green','LineWidth',1)
hold on
plot(time_plot,out_r_of,'black','LineWidth',1)
hold on
plot(time_plot,out_watershed(1:length(time_plot)),'--Red','LineWidth',2)
hold on
yyaxis right
plot(time_plot,i_reservoir(1:n_steps),'blue')
set(gca,'ydir','reverse')
set(gca,'FontSize',12)
xlabel('Elapsed Time (hr)'); ylabel('Flow (cms)')
legend('Optim','Passive','Detention','On/Off','Inflow')
% Reservoir Water Levels
subplot(2,2,2)
plot(time_plot,x_r_final,'red','LineWidth',1)
hold on
plot(time_plot,h_r_passive,'blue','LineWidth',1)
hold on
plot(time_plot,h_r_DC,'green','LineWidth',1)
hold on
plot(time_plot,h_r_of,'black','LineWidth',1)
set(gca,'FontSize',12)
xlabel('Elapsed Time (hr)'); ylabel('Water Level (m)')
legend('Optim','Passive','Detention','On/Off')
% Channel Maximum Water Level
subplot(2,2,3)
plot(time_plot,max(h_c_final),'red','LineWidth',1)
hold on
plot(time_plot,max(h_c_passive),'blue','LineWidth',1)
hold on
plot(time_plot,max(h_c_DC),'green','LineWidth',1)
hold on
plot(time_plot,max(h_c_of),'black','LineWidth',1)
set(gca,'FontSize',12)
xlabel('Elapsed Time (hr)'); ylabel('Channel Water Level (m)')
legend('max(h_{c,Optim})','max(h_{c,passive})','max(h_{c,DT})','max(h_{c,OnOff})')
hold off
% Controls
subplot(2,2,4)
plot(time_plot,u_final(1:length(time_plot)),'red','LineWidth',1)
hold on
plot(time_plot,u_passive(1:length(time_plot)),'blue','LineWidth',1)
hold on
plot(time_plot,u_DC(1:length(time_plot)),'green','LineWidth',1)
hold on
plot(time_plot,u_of(1:length(time_plot)),'black','LineWidth',1)
set(gca,'FontSize',12)
xlabel('Elapsed Time (hr)'); ylabel('Control Signal')
legend('h_{Optim}','h_{PC}','h_{DT}','h_{OnOff}')
hold off
export_fig Controls_Analysis -m5 -q101 -nocrop
