%this script creates a map

close all

f = record_time_maps;
t_max = tfinal;
%% plot DEM
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'DEM.gif';
a_grid = Delta_x;
b_grid = Delta_y;
for t = 1:5
% Draw plot for d = x.^n
    z = DEM;
    xmax = length(z(1,:));
    xend = xmax;
    ymax = length(z(:,1));
    yend = ymax;
    xbegin = 1;
    ybegin = 1;
    max_h = max(max(max(z)))
    h_max = round(max_h/10,0)*10*1.05;
    x_grid = [xbegin:1:xend]; y_grid = [ybegin:1:yend];
    z(z<=0)=inf;
    h_min = floor(min(min(z))/10)*10;
    F = DEM(y_grid,x_grid);
    zmax = max(max(max(z(~isinf(z)))));
    surf(x_grid*a_grid,y_grid*b_grid,F);
    set(gca,'Ydir','reverse')
    %shading INTERP;
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid h_min zmax])
    view(15,-60);
    colorbar
    caxis([h_min zmax]);
    colormap(jet)
    hold on
    %set(gca,'Ydir','reverse')
    title('DEM')
    k = colorbar 
    ylabel(k,'Elevation (m)')
    xlabel(' x (m) ')
    ylabel ('y (m) ')
    zlabel (' depths')
    drawnow 
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if t == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
end  
clf
%% plot depths
% Adjusting the size
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'depths.gif';
set(gcf,'units','inches','position',[0,0,14,14])
for t = 1:f:(tfinal + 1)
    subplot(2,2,1)
    scale = 1000; 
    t_title = time_records(t);
    % Draw plot for d = x.^n
    z = reshape(d,[rows,cols,tfinal+1])*(1000/scale) + DEM; %plotting only the excedance of the h_0
    z(z<=0)=inf;
    F = z(y_grid,x_grid,t);
    zmax = max(max(max(z(~isinf(z)))));
    surf(x_grid*a_grid,y_grid*b_grid,F); 
    shading INTERP;
    set(gca,'Ydir','reverse')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid 0 zmax])
    title(sprintf('Time(min) = %d',t_title),'FontSize',14)
    view(15,-60);
    colorbar
    caxis([0 zmax]);
    colormap(jet)
    k = colorbar
    ylabel(k,'DEM + 10^3*Depth','FontSize',14)
    xlabel(' x (m) ')
    ylabel ('y (m) ')
    zlabel ('DEM + 10^3*Depth','FontSize',14)
    drawnow 
    subplot(2,2,2)
    z = i; % Rainfall (2D)
    z(z<=0)=inf;
    F = z(y_grid,x_grid,t);
    zmax = max(max(max(z(~isinf(z)))));
    surf(x_grid*a_grid,y_grid*b_grid,F); 
    shading INTERP;
    %set(gca,'Ydir','reverse')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid 0 zmax])
    title(sprintf('Time(min) = %d',t_title),'FontSize',14)
    view(0,90);
    colorbar
    caxis([0 zmax]);
    colormap(jet)
    k = colorbar
    ylabel(k,'$$\hat{i(t)}$$','Interpreter','Latex','FontSize',14)
    xlabel(' x (m) ','FontSize',14)
    ylabel ('y (m) ','FontSize',14)
    zlabel ('Water Surface Elevation','FontSize',14)   
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if t == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
    subplot(2,2,3)
    z = reshape(d,[rows,cols,tfinal+1]) - DEM; % only the water level
    z(z<=0)=inf;
    F = z(y_grid,x_grid,t);
    zmax = max(max(max(z(~isinf(z)))));
    surf(x_grid*a_grid,y_grid*b_grid,F); 
    shading INTERP;
    %set(gca,'Ydir','reverse')
    axis([xbegin*a_grid xend*a_grid ybegin*b_grid yend*b_grid 0 zmax])
    title(sprintf('Time(min) = %d',t_title),'FontSize',14)
    view(0,90);
    colorbar
    caxis([0 zmax]);
    colormap(jet)
    k = colorbar
    ylabel(k,'Depths (mm)')
    xlabel(' x (m) ')
    ylabel ('y (m) ')
    zlabel ('Water Surface Elevation')   
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if t == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
      subplot(2,2,4)
      plot(time_records(1,1:t),flow_outlet((1:t),1),'red','LineWidth',2)
      xlabel('Time (min)','FontSize',14)
      ylabel('Flow (m^3/s)','FontSize',14)
      title('Outlet Hydrograph','FontSize',14)
    
end

