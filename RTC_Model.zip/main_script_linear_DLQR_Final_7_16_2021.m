%% Watershed + Linearized Reservoir and Channel Dynamics
% 5/7/2021
% Developer: Marcus Nobrega
% Objective: Main file for the MPC controller
clear all
clc
global out_w time_step n_steps Control_Vector Nvars i_reservoir 
%% 1.0 - Topologic Matrices for the Watershed Model
[DEM,n,h_0,ksat,dtheta,F_0,psi,d_0,Delta_x,Delta_y] = gridded_data(); % V-tilted
%[DEM,n,h_0,ksat,dtheta,F_0,psi,d_0,Delta_x,Delta_y] = gridded_parking();
idx = find(DEM == inf);
% This line below test an algorithm to fill the sinks
    DEM_1 = nosink(DEM); DEM_2 = DEM; DELTA = DEM_1 - DEM_2; %surf(DELTA);
 max_fill = max(max(DELTA));
 % coordinate system from left up corner (x -->) y (down)
[row, col] = find(DEM == min(min(DEM)));
coord_outlet = [row,col];
dim = size(DEM); rows = dim(1); cols = dim(2); % Outlet Position
[f_dir] = FlowDirection(DEM ,Delta_x,Delta_y,coord_outlet); % Flow direction matrix
slope_outlet = 0.02; % m/m
[slope] = max_slope8D(DEM,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet);
[Direction_Matrix] = Find_D_Matrix(f_dir,coord_outlet);
%% 2.0 - Defining simulation duration
tfinal = 132475 + 24*60; % min
% tfinal = 1440; % min
time_step = 5; % seconds
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); %number of steps
%% 2.0 - Calculating Flow Constants
% Q = (1/n)*A*Rh^(2/3)*slope^(0.5), A = (Delta_x + Delta_y)/2*d, 
% Rh = A / ((Delta_x + Delta_y)/2 + d) <=> for d << (Delta_x + Delta_y)/2,
% Rh = d -> Q = (1/n)*(Delta_x + Delta_y)/2*d^(2/3)*slope^(0.5)
% Q = (1/n*(Delta_x + Delta_y)/2)*slope(^0.5)*d^(5/3)
% Q = Lambda_1*d^(5/3)
% Lambda_1 = (1/n*(0.5*Delta_x + 0.5*Deltay))*slope^(0.5)
% q = Q / (Delta_x*Delta_y); 
resolution = (Delta_x + Delta_y)/2;
Lambda = (resolution)*(1./n).*slope.^(0.5); % Be careful here
Lambda(idx) = 0;
Lambda = real(Lambda);
Lambda = Lambda(:); % Creating a 1D array
Vcr = (9.81*resolution)^0.5; % critical velocity in m/s
%% 3.0 - Recording Data into a defined step (e.g., each 1-min)
record_time_maps = 15; % time that values will be saved in minutes (e.g., 0.5 it will save each 30 sec)
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step
%% 4.0 - Initial Conditions for the Watershed Model
t = 0;
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d;
flow_outlet = zeros(length(time_store),1);
d(:,1) = d_0(:);
% Inflows 
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 - Rainfall Model 
[i,i_0] = rainfall_model(rows,cols,time_store,number_of_records,record_time_maps); % Results in 3-D arrays
i = reshape(i,dim(1)*dim(2),length(time_store)); % Results in 2-D array
i_0 = i_0(:);
%% 6.0 - Outlet Position in the concatenated states
% Position in the vector
% Given a 2-D position (eow,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1; 
pos = (col-1)*rows + row;
% Output function of 1 watershed
out_w = zeros(n_steps,1); % Catchment Outflow (cms)
out_w(1,1) = flow_outlet(1,1);
%%%% Creating concatenated 1D arrays %%%
n = n(:);
h_0 = h_0(:); 
ksat = ksat(:);
dtheta = dtheta(:);
F_0 = F_0(:);
psi = psi(:);
d_0 = d_0(:);
% Initial Inflow
[inflows] = non_lin_reservoir(Lambda,d_0,h_0,Delta_x,Delta_y);
flow_outlet(1,1) = inflows(pos);
t_store = 1;
%% 7.0 - Solving the Water Balance Equations for the Watersheds
for k = 1:(n_steps - 1)
    % Call the Watershed Matrix Model
    [F_d,d_t,flow_t] = wshed_matrix(d_0,h_0,inflows,time_step,Inflow_Matrix,Direction_Matrix,i_0,ksat,psi,dtheta,F_0,Lambda,Delta_x,Delta_y);
    % Saving variables with user defined recording time-step
        if k == 1
            % Do nothing, it is already solved, we just have to save the data
            % for the next time-step
        elseif find(time_store == k) > 0
            t_store = find(time_store == k); % Time that is being recorded in min
            d(:,t_store) = d_t(:);
            flow_outlet(t_store,1) = flow_t(pos)*(Delta_x*Delta_y)/(1000*3600); % Flow in cms
            I(:,t_store) = (F_d); % stored depth in mm
        end
    % Saving variables for the next time-step
    F_0 = F_d; % Accumulated Infiltration in (mm)
    z = min(find(time_store >= k)); % Position of raifall
    i_0 = i(:,z); % Initial Rainfall for the next time-step
    d_0 = d_t; % Depths to the next time-step in mm
    inflows = flow_t; % Inflows to the next time-step in mm/h
    % Output Function - Inflow for the Reservoir = Outflow from the
    % Catchment
    out_w(k,1) = flow_t(pos)*(Delta_x*Delta_y)/(1000*3600); % Outflow (cms)
    dmax = d(pos,t_store) % Show the depth at the outlet
end
%% 8.0 - Setting initial parameters for Reservoir and Channel Dynamics
i_outlet = squeeze(i(row,col,:));
% Rainfall in the Reservoir
i_reservoir = zeros(n_steps,1);
for k =1:(n_steps-1)
    z = find(time_store >= k, 1 ); % Position of raifall
    i_reservoir(k,1) = i_outlet(z,1); % Initial Rainfall for the next time-step
end
%% Agregating time-step to increase speed
% Agregating the Inflow to a larger time-step
% load out_w_10_yr
% load i_reservoir_data
% load out_w_12h
% load i_reservoir_12_h
% load i_reservoir_12h_25yr_12h_10yr
% load out_w_12h_25yr_12h_10yr;
load out_w_2months
load i_reservoir_2months
% All this loadings is to avoid to run the watershed model
flow_timestep = time_step;
new_timestep = 5; % seconds;
inflow_timesteps = n_steps; % Number of time-steps using the watershed time-step
n_steps = (n_steps-1)*time_step/new_timestep; % adjusting the new number of time-steps
out_watershed_disagregated = out_w;
agregation_step = new_timestep/time_step; % number of time-steps in on agregation time-ste0
for i = 1:(inflow_timesteps/agregation_step)
    if new_timestep >= time_step
        flow_agregated(i,1) =  mean(out_watershed_disagregated(1 + (i-1)*agregation_step:i*agregation_step,1));
        i_reservoir_agregated(i,1) = mean(i_reservoir(1 + (i-1)*agregation_step:i*agregation_step,1));
    else
        flow_agregated(i,1) =  out_watershed_disagregated(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
        i_reservoir_agregated(i,1) = i_reservoir(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
    end
end
out_w = flow_agregated;
i_reservoir = i_reservoir_agregated;
time_step = new_timestep;

%%
clearvars -except out_w time_step n_steps Control_Vector Nvars i_reservoir out_www
% Channel parameters
[cell_area,y_cells,x_cells,segments,h_radius,h_radius_23,wet_area,outflow,elevation,roughness,slope_out] = channel_parameters(time_step,n_steps);
% Dir Matrices and Slope Matrices
[dir_matrix,A_slope,B_slope] = dir_slope_matrices(segments,y_cells,elevation,slope_out);
% Notation
% (w) - watershed, (r) - Reservoir, (c) channel
% Initial Operation Point for the reservoir
u_eq = 0.1; % between 0 and 1
h_eq = 0; % (m)
h_rt = 0; % Water level in real time (t = 0) in (m);
% Inflow in the Reservoir
Qin_r = out_w; % Reservoir inflow from the catchment in cms
Qin_rt = out_w(1,1); % Initial reservoir inflow in cms
% Inflow in the Channel
Qin_c = zeros(segments,1);
% Initial Water Depths in the Channel
h_0_c = zeros(segments,1);
% Channel Routing Differential Equation h_dot_channel(:,1) = gama_c(1);
gama_c = 1./cell_area.*(dir_matrix*(1./roughness.*wet_area(h_0_c,x_cells).*h_radius_23(h_0_c,x_cells).*(A_slope*h_0_c + B_slope).^(1/2)) + Qin_c);
% Saving Jacobians alfa_1 alfa_2 beta_1 and beta_2 in a symbolic fashion
[alfa_1_function,alfa_2_function,beta_1_function,beta_2_function] = symbolic_jacobians(); %
%% 9.0 - Running the Model 
Control_Interval = 15; % minutes
Control_Vector = [1:Control_Interval*60/(time_step):n_steps];
x = zeros(n_steps,segments+1);
u = zeros(n_steps,1);
out_r_plot = zeros(n_steps,1);
out_c_plot = zeros(n_steps,1);
% Augmented Dynamics
X = zeros(n_steps,2);
U = 0*ones(n_steps,1);
zzz = [0];
xeq = [0];
for k = 1:(n_steps -1)
    % Rainfall in the Reservoir
    perc = k/n_steps*100
    i_0 = i_reservoir(k,1); % Initial Rainfall for the next time-step
    % Call Reservoir Routing
    [A_res, B_res,fi_res,out_r,outflow_eq,alfa,beta] = state_matrices_reservoir(Qin_rt,h_eq,u_eq,h_rt,time_step,alfa_1_function,alfa_2_function,beta_1_function,beta_2_function,i_0);    % Call Channel Routing
    [A_chan,fi_c,out_c] = state_matrices_channel(time_step,segments,gama_c,dir_matrix,x_cells,A_slope,B_slope,roughness,h_0_c,cell_area,outflow);    % Concatenate State-Space 
    A = blkdiag(A_res,A_chan);
    n_res = size(A_res,1); % Number of Reservoirs
    n_states = size (A,1); % number of states
    % Variables
    nx = n_res;
    ny = n_res;
    nu = size(B_res,2);
    C_res = 1; % Assuming we observe all states (reservoir)
    D_res = zeros(ny,nu);
    B = [B_res;zeros(n_states - n_res,1)];
    fi = [fi_res;fi_c];
    % Discrete Linear Quadratic Integrator
        if find(Control_Vector == k) > 0
            Q = blkdiag(1);
            R = 1;
            N = 0;
             if B_res == 0 % Checking controlability
                 K = 0;
             else
                [K] = dlqr(A_res,B_res,Q,R,N);
             end
            % Control Signal - Only Reservoir
            %u(k+1) = max(-K(1)*x(k,1),0); % Lower Boundary
            u(k) = -K*(x(k,1) - xeq);
            u(k) = max(-K*x(k,1),0);
            u(k) = min(-K(1)*x(k,1),1);
        else
            % Checking if it is the 1st step
            if k == 1
                u(k) = u(k);
            else
                u(k) = u(k-1);
            end
        end
            
    if x(k,1) > 4.5
       tttt = 1;
    end
    % Reservoir + Channel Dynamical System
    % x(k+1,:) = A*x(k,:)' + B*u(k,:)' + fi;
    x(k+1,:) = A*x(k,:)' + B*u(k,:)' + fi;
    % Assigning Values for the next-time step for the Reservoir
    Qin_rt = Qin_r(k+1);
    h_eq = max(x(k,1),0);
    xeq = h_eq;
    u_eq = u(k);
    h_rt = max(x(k+1,1),0);
    % Assigning Values for the next time-step for the Channel
    Qin_c(1,1) = out_r;
    gama_c = 1./cell_area.*(dir_matrix*(1./roughness.*wet_area(h_0_c,x_cells).*h_radius_23(h_0_c,x_cells).*(A_slope*h_0_c + B_slope).^(1/2)) + Qin_c);
    h_0_c = x(k+1,2:end)';
    out_r_plot(k) = out_r;
    out_c_plot(k) = out_c;
end
u(k) = u(k-1);
% Final Variables
h_r = x(:,1);
h_c = x(:,2:end);
%% Plot Results
graphs_wshed_reservoir_channel_linearized_DLQR