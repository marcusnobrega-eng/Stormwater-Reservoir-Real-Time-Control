%% Channel Routing Script - (Non-Linear Dynamics)
% Developer - Marcus Nobrega
% 4/23/2021
% Objective: Develop a 1-D model of Manning's equation for a open Channel
% using 1-D gridded cells and calculating the maximum water level for each
% time-step
% function [max_water_level] = channel_routing(Qin,time_step)
Qin = out_r; % Input Hydrograph in (m3/s) from the Catchments
delta_t = time_step;
x_length = 3;
y_length = 30;
% Manning's
roughness = 0.3;
% Noise in Manning
average = 0;
variance = 0.00;  % r = (1 + average + sqrt(variance).*randn())
% Number of Segments
segments = 100;
x_cells = repmat(x_length,[segments,1]);
y_cells = repmat(y_length,[segments,1]);
roughness = repmat(roughness,[segments,1]);
% Elevation Calculation
s = 0.025; % slope m/m
slope_out = 0.025; % Outlet slope m/m
h_end = 0; % m
% Bottom Elevation
for i = 1:segments
    if i == 1
        elevation(1,1) = sum(y_cells*s)+ h_end;
        % r = (1 + average + sqrt(variance).*randn())
        r = (1 + average + sqrt(variance).*randn());
        roughness(i) = roughness(i)*r;
    else
        elevation(i,1) = elevation(i-1) - s*y_cells(i-1);
        % r = (1 + average + sqrt(variance).*randn(dim(1),dim(2)))
        r = (1 + average + sqrt(variance).*randn());
        roughness(i) = roughness(i)*r;
    end
end
% Cells Area
cell_area = x_cells.*y_cells; % m^2
% Initial Water Level
H_0 = 0;
H_0 = repmat(H_0,[segments,1]);
n_cells = length(x_cells);
slope = zeros(n_cells,1);
%% 1.0 - Topographic Slopes
for i = 1:(n_cells-1)
    slope(i) = (elevation(i) - elevation(i+1))/(y_cells(i)); % m/m
end
slope(n_cells) = slope_out; % outlet

%% 2.0 - Hydraulic Radius and Area Function
h_radius = @(h,b) ((b.*h)./(b + 2*h)); % User defined hydraulic radius function
wet_area = @(h,b) (b.*h); % User defined cross section area function
outflow = @(h,b,roughness,slope) (1./roughness.*wet_area(h,b).*((h_radius(h,b).^(2/3))).*(slope.^(0.5))); % Manning's
h_c = zeros(n_cells,n_steps); h_c(:,1) = H_0; h_0_c = H_0;
out_c_cells = zeros(n_cells,n_steps);
%% Topology Relationships
% Direction Matrix
dir_matrix = (-1)*eye(n_cells,n_cells);
% Slope(k+1) = Aslope*h(k) + Bslope
% Bslope = alfa*theta*elevation
% Aslope = alfa*theta
% alfa = tau*y_cells
% Beta = [0; 0; ... 0; s_outlet];
theta(segments) = 0; % Outlet Cell
theta = eye(segments); % Slope Conection Matrix
tau = 0.5*eye(segments); % Slope Distance Matrix
tau(segments,segments) = 0; % Outlet Cell
beta = zeros(n_cells,1); 
beta(n_cells) = slope_out; % Outlet Slope
for i = 1:(n_cells - 1)
        dir_matrix(i+1,i) = 1;
        theta(i,i+1) = -1; % [1-1 0 0; 0 1 -1 0 ...]
        tau(i,i+1) = 0.5;
end
alfa = (tau*y_cells).^-1; % 1/Horizontal Distance between cells (m^-1);
alfa(segments) = 0;
alfa = diag(alfa); % Transforming into a diagonal format
B_slope = alfa*theta*elevation + beta;
A_slope = alfa*theta;
inflow = outflow(h_0_c,x_cells,roughness,slope);
max_water_level = zeros(n_steps,1); % Maximum Water Level in the Channel (m)
wshed_inflow = zeros(n_cells,n_steps); 
wshed_inflow(1,:) = Qin(:); % Assuming the inflow from the reservoir only for the 1st cell
%% 3.0 - Routing Flow
for k = 1:(n_steps-1)
    % Implementing Water Balance  Numerical Constraint of no negative
    % depth - h(k+1) = max(h(k+1),0)
    h_c(:,k+1) = max(h_0_c + delta_t*(1./cell_area).*(dir_matrix*inflow + wshed_inflow(:,k)),0);
    h_0_c = h_c(:,k+1); % Depths for the next time step
    % Slopes Calculation assuming the Water Level of (k-1)
%     for i = 1:(n_cells-1)
%         slope(i) = (elevation(i) + h_0_c(i) - elevation(i+1) - h_0_c(i+1))/((y_cells(i) + y_cells(i+1))/2); % m/m
%     end
     slope = A_slope*h_0_c + B_slope;
    % Inflows for the next time step
    inflow = outflow(h_0_c,x_cells,roughness,slope);
    if max(inflow) > 5
        ttttt = 1;
    end
    max_water_level(k+1) = max(h_c(:,k+1)); % Maximum water level in the channel in (m)
    out_c_cells = outflow(h_0_c,x_cells,roughness,slope);
    out_c(k,1) = out_c_cells(segments,1);
end
