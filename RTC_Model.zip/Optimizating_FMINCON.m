%% Main File - MPC solver for the Watershed + Reservoir + Channel system
% Developer: Marcus Nobrega Gomes Junior
% 8/1/2021
% Main Script 
% Goal: Create the main file containing:
% a) Watershed Model
% b) Connection between the Optimization Function and the Solvers
% c) Plant Models of the Reservoir and Channel
% d) Saving final results

clear all
clc
global Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance
%% 1.0 - Gridded Information of Watershed Properties
% We need matrices representing the DEM, roughness, initial abstraction,
% saturated hydraulic conductivity, inintial infiltrated depth, suction
% head, as well as cell resolutions for x and y directions.

% The following function estimates it for the V-Tilted Catchment. However,
% you might change it loading these aforementioned files below.

%%%%%%%%%%%%%%%%%%%%%%% V-Tilded Data %%%%%%%%%%%%%%%%%%%%%%%
[DEM,n,h_0,ksat,dtheta,F_0,psi,h_ef_w_0,Delta_x,Delta_y] = gridded_data(); % V-tilted (7/24/2021 - Overland Flow)
%%%%%%%%%%%%%%%%%%%%%%% V-Tilded Data %%%%%%%%%%%%%%%%%%%%%%%

% See an example of how you could do in case you want to log a different
% watershed
% In case manual text files are inputed, please make sure to load them
% folowing this:
%   load DEM
%   load n
%   load h_0
%   load ksat
%   load dtheta
%   load F_0
%   load psi
%   load h_ef_w_0
%   Delta_x = %%% length of the cells in meters
%   Delta_y = %%% width of the cells in meters

%%% Parking Lot Catchment %%%
%[DEM,n,h_0,ksat,dtheta,F_0,psi,h_ef_w_0,Delta_x,Delta_y] = gridded_parking();

%%% 1.1 - Filling Sinks %%%
% We are using a kinematic wave approximation for the Saint Vennant
% Equations. Therefore, we need to assign a flow direction for each cell.
% In other words, cells with sinks have to be filled. The following
% calculations fill sinks in the DEM.
idx = find(DEM == inf);
% This line below test an algorithm to fill the sinks
DEM_1 = nosink(DEM); DEM_2 = DEM; DELTA = DEM_1 - DEM_2; %surf(DELTA);
max_fill = max(max(DELTA));
%%% 1.2 - Flow Direction, Slope and Direction Matrix %%%
 % coordinate system from left up corner (x -->) y (up-down)
[row, col] = find(DEM == min(min(DEM)));
coord_outlet = [row,col];
dim = size(DEM); rows = dim(1); cols = dim(2);
%%%% Flow Direction %%%%
[f_dir] = FlowDirection(DEM ,Delta_x,Delta_y,coord_outlet); % Flow direction matrix
slope_outlet = 0.02; % m/m - Gradient slope boundary condition
%%%% Slope Calculation %%%%
[slope] = max_slope8D(DEM,Delta_x,Delta_y,coord_outlet,f_dir,slope_outlet);
%%%% Direction Matrix %%%%
[Direction_Matrix] = Find_D_Matrix(f_dir,coord_outlet);
%% 2.0 - Defining simulation duration
% tifnal is the final minute where the simulation is performed. It has to
% be larger than the rainfall duration in order to make sure the hydrograph
% is propagated properly
tfinal = 132475 + 24*60; % min
time_step = 5; % Time-step of the watershed hydrological model in (seconds)
time = (0:time_step:tfinal*60)/60; % time vector in min
n_steps = length(time); % number of steps
%% 2.0 - Calculating Flow Constants
resolution = (Delta_x + Delta_y)/2;
Lambda = (resolution)*(1./n).*slope.^(0.5); % Lumped hydraulic properties
Lambda(idx) = 0;
Lambda = real(Lambda);
Lambda = Lambda(:); % Concatenated Lambda resultin in a 1-D array
Vcr = (9.81*resolution)^0.5; % critical velocity in m/s
%% 3.0 - Recording Data into a defined step (e.g., each 1-min)
record_time_maps = 15; % time that values will be saved in minutes (e.g., 0.5 it will save each 30 sec)
number_of_records = floor((n_steps-1)*time_step/(record_time_maps*60)); % number of stored data (size of the vector)
time_records = [0:record_time_maps:tfinal]; % time in minutes
% vector to store data
time_store = time_records*60./time_step; % number of steps necessary to reach the recording vector
time_store(1) = 1; % the zero is the firt time step
%% 4.0 - Initial Conditions
d = zeros(numel(DEM),length(time_store)); flow_t = d; I = d;
flow_outlet = zeros(length(time_store),1);
h_ef_w(:,1) = h_ef_w_0(:);
% Inflow_Matrix
Inflow_Matrix = Direction_Matrix;
Inflow_Matrix(Inflow_Matrix == -1) = 0;
%% 5.0 - Rainfall Model 
[i,i_0] = rainfall_model(rows,cols,time_store,number_of_records,record_time_maps); % Results in 3-D arrays
i = reshape(i,dim(1)*dim(2),length(time_store)); % Results in 2-D array
i_0 = i_0(:);
%% 5.0 - Outlet Position in the concatenated states
% Position in the vector
% Given a 2-D position (eow,col), where row is the row of the outlet and col, the
% collumn of the outlet, we can find pos, such that:
% pos = (y1-1)*rows + x1; 
pos = (col-1)*rows + row; % Outlet vector containing the position of the outlet
% Output function of 1 watershed
Qout_w = zeros(n_steps,1); % Catchment Outflow (cms)
Qout_w(1,1) = flow_outlet(1,1);
%%%% Creating concatenated 1D arrays %%%
n = n(:);
h_0 = h_0(:); 
ksat = ksat(:);
dtheta = dtheta(:);
F_d = F_0(:);
psi = psi(:);
h_ef_w = h_ef_w_0(:);
% Initial Inflow
[inflows] = non_lin_reservoir(Lambda,h_ef_w,h_0,Delta_x,Delta_y);
flow_outlet(1,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Initial Outflow
t_store = 1;
ETP = 2;
%% 6.0 - Solving the Water Balance Equations for the Watersheds
for k = 1:(n_steps - 1)
    tic
    % Call the Watershed Matrix Model
    [F_d,h_ef_w,inflows] = wshed_matrix(h_ef_w,h_0,inflows,time_step,Inflow_Matrix,Direction_Matrix,i_0,ksat,psi,dtheta,F_d,Lambda,Delta_x,Delta_y,ETP);
    % Saving variables with user defined recording time-step
        if k == 1
            % Do nothing, it is already solved, we just have to save the data
            % for the next time-step
        elseif find(time_store == k) > 0
            t_store = find(time_store == k); % Time that is being recorded in min
            d(:,t_store) = h_ef_w(:); % Depths in mm
            flow_outlet(t_store,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Flow in cms
            I(:,t_store) = (F_d); % stored depth in mm
        end
    % Saving variables for the next time-step
    % I_0 = I_t; h_ef_w( = d_t; inflows = flow_t (all from the wshed matrix
    % function
    z = find(time_store >= k, 1 ); % Position of raifall
    i_0 = i(:,z); % Initial Rainfall for the next time-step
    % Output Function - Inflow for the Reservoir = Outflow from the
    % Catchment
    Qout_w(k,1) = sum(inflows(pos)*(Delta_x*Delta_y)/(1000*3600)); % Outflow (cms)
    perc = k/(n_steps-1)*100;
    info = [perc] % Showing the depths at the outlet and the percentage of the calculations a
end
time_wshedmodel = toc/60;
%% Modeling Reservoir + Channel Dynamics
ur_eq = 0; % Initial equilibrium point, between 0 and 1
hr_eq = 0.1; % Initial equilibrium point (water level in the pond) in (m)
% Pre allocating arrays
h_r = zeros(n_steps,1); % Depth in the reservoir (m)
h_rt = 0; % Initial Water Level in the Reservoir
i_outlet = i(pos,:)';
i_reservoir = zeros(n_steps,1);
% Evaporation in the Reservoir (timeseries or constant value)
% E = 4.1092; % mm/day - Average ETP in San Antonio
E = 2; % mm/day
for k =1:(n_steps-1)
    z = find(time_store <= k,1,'last'); % Be careful here
    i_reservoir(k,1) = i_outlet(z,1) - E/24; % Initial Net Rainfall for the next time-step
end
%% Agregating time-step to increase speed
% Agregating the Inflow to a larger time-step
% You can either enter with your observed outflow from the watershed and
% observed rainfall or use the ones calculated previously.
% To gain velocity, we can enter these values loading these files below
    % load out_w_10_yr
    % load i_reservoir_data
    % load out_w_12h
    % load i_reservoir_12_h
    % load i_reservoir_12h_25yr_12h_10yr
    % load out_w_12h_25yr_12h_10yr;
load out_w_2months
load i_reservoir_2months
% E = 3.6689; % Average gross evaporation in San Antonio mm/day
E = 2; % mm/day
%%%% Net Rainfall i'(k)
i_reservoir = i_reservoir - E/24; % Rainfall intensity - Evaporation Intensity (mm/h)
% All this previously done is to to avoid to run the watershed model, but
% you can run of course
flow_timestep = time_step;
new_timestep = 5; % seconds; % We can use a coarser or a finer time-step for the reservoir and channel dynamics
inflow_timesteps = n_steps; % Number of time-steps using the watershed time-step
n_steps = (n_steps-1)*time_step/new_timestep; % adjusting the new number of time-steps
Qout_w_disagregated = Qout_w;
agregation_step = new_timestep/time_step; % number of time-steps in on agregation time-step
% Disagregating or Agreagating flows and rainfall
for i = 1:(inflow_timesteps/agregation_step-1)
    if new_timestep >= time_step
        flow_agregated(i,1) =  mean(Qout_w_disagregated(1 + (i-1)*agregation_step:i*agregation_step,1));
        i_reservoir_agregated(i,1) = mean(i_reservoir(1 + (i-1)*agregation_step:i*agregation_step,1));
    else
        flow_agregated(i,1) =  Qout_w_disagregated(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
        i_reservoir_agregated(i,1) = i_reservoir(1 + floor((i-1)*agregation_step):ceil(i*agregation_step));
    end
end
% Defining newer outflows from the watershed, rainfall intensity and
% time_step
Qout_w = flow_agregated;
i_reservoir = i_reservoir_agregated;
time_step = new_timestep;
%% Calling MPC control
% Let's clear variables we don't use to avoid computational burden
clearvars -except Qout_w Qout_w_horizon steps_control_horizon steps_horizon time_step n_steps Control_Vector Nvars i_reservoir h_c_0 h_r_t ur_eq_t i_reservoir_horizon previous_control average variance
tic
% For the MPC Control, we need to define the following variables:
Control_Interval = 60; % actions are taken in this interval (min)
Control_Horizon = 120; % we plan and implement control in this horizon and move foward (min)
Prediction_Horizon = 2*60; % (min) we solve the optimization problem for this duration, implement actions for 1 control horizon and move 1 control horizon

% A few vector calculations
steps_control_horizon = Control_Horizon*60/time_step; % number of steps in the control horizon;
n_controls = Control_Horizon/Control_Interval; % number of controls to choose from an optimization problem
steps_horizon = Prediction_Horizon*60/time_step; % number of steps in one prediction horizon

% out_watershed = Qout_w; % watershed inflow
Qout_w(length(Qout_w):(length(Qout_w)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
i_reservoir(length(i_reservoir):(length(i_reservoir)+steps_horizon),1) = 0; % adding more variables to the inflow to account for the last prediction horizon
n_horizons = (n_steps)/(Control_Horizon*60/time_step); % number of control horizons 
Control_Vector = [0:Control_Interval:Prediction_Horizon]*60/time_step;
Nvars = length(Control_Vector);

% Objective Function
fun = @Optimization_Function;

% Optmizer - Solver
%%%% Interior Point %%%
% options = optimoptions(@fmincon,'MaxIterations',10,'MaxFunctionEvaluations',50); % Previously
% options = optimoptions(@fmincon,'MaxIterations',10,'MaxFunctionEvaluations',50);
%%%% Genetic Algorithm %%%%
options = optimoptions('ga',...
                       'MaxGenerations',5,...
                       'PopulationSize',10,...
                       'TolFun',1e-1);
% options = optimoptions('ga','PlotFcn','gaplotbestf',...
%                        'MaxGenerations',5,...
%                        'PopulationSize',100,...
%                        'TolFun',1e-1);       

%%%% To increase the chances of finding global solutions, we solve the problem
% for n_randoms initial points %%%%

%%%% Estimate random initial points for the Random Search %%%%
n_randoms = 2;
matrix = rand(Nvars,n_randoms);
% u(k+1) = u(k)*rand(0,0.2)
%%% Range of the Initial Values %%%
a = -0.2; % initial values varies within this range from the previous last value
b = 0.2;
%     matrix(:,1) = 0;
%     matrix(:,2) = 0.5;
%     matrix(:,3) = 1;
% Matrices for FMINCON
A = []; B = []; Aeq = [];Beq = []; Lb = zeros(Nvars,1); Ub = ones(Nvars,1);
%%% Prealocatting Arrays %%%
h_r_final = zeros(n_steps,1);
h_c_final = zeros(100,n_steps); % 100 is the number of sub-reaches in the channel plant
% Initial Conditions (Reservoir and Channel)
h_r_t = 0;
ur_eq_t = 0;
h_c_0 = zeros(100,1);
U = zeros(Nvars,1); % Concatenation of future control signals
previous_control = 0;
u = 0; % initial control
for i = 1:n_horizons
    perc = i/n_horizons
    % Define inflow from the catchment throughout the prediction horizon
    time_begin = (i-1)*steps_control_horizon + 1; % step
    t_min = time_begin*time_step/60; %  time
    time_end = time_begin + steps_horizon; 
    t_end = time_end*time_step/60; % final time of the current step
    time_end_saving = time_begin + steps_control_horizon-1; % for saving
    
    Qout_w_horizon = Qout_w(time_begin:time_end,1); % Result of the Watershed Model
    i_reservoir_horizon = i_reservoir(time_begin:time_end,1); % Result of the Rainfall Forecasting
    %%% GENETIC ALGORITHM SOLUTION %%%
    %     % Call Genetic Algorithm
    %     [U,fval,exitflag,output,population] = ga(@GA_Objfun, Nvars,[],[],[],[],lb,ub,[],[],options);
    %%%% Call FMINCON solution %%%%
    % Determining random initial points
    
    %%% Noise Generation - Prediction %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below
    average = 0.0; % average noise in (m)
    variance = 0; % variance in (m2). Remember that xbar - 2std has a prob of 93... %, std = sqrt(variance)
    
    % Generating initial estimates for the search algorithm
    for j=1:n_randoms
        if u(end,1) == 0 % In case the previous control equals zero
            u0 = matrix(:,j); % Random numbers
            u0(1) = U(n_controls);
        else
            u0 = U(n_controls)*(a + matrix(:,j)*(b - a)); % randomly select values within the adopted range
            u0(1) = U(n_controls); % the initial estimative is the previous adopted
        end
        if max(Qout_w_horizon) == 0 % If the maximum predicted outflow is zero
            U = ur_eq_t*(ones(Nvars,1)); % Here you can either choose to open the valves or close them, in case you want to increase detention time
        else
            %%% Solving the Optimization Problem for the Random Initial
            %%% Points
%             [U,FVAL] = fmincon(fun,u0',A,B,Aeq,Beq,Lb,Ub,[],options);  % Fmincon solutions          
            [U,FVAL] = ga(fun,Nvars,A,B,Aeq,Beq,Lb,Ub,[],options); % GA solutions
            OF(j) = FVAL; % saving the objective function value
            U_random(:,j) = U'; % saving the control vector     
            position = find(OF == min(OF)); % position where the minimum value of OF occurs
            U = U_random(:,position); % Chosen control            
        end
    end
    controls((i-1)*n_controls + 1:i*n_controls,1) = U(1:n_controls)';
    % Implement the Controls in the Plant and Retrieve Outputs
    %%% Run the Model with the estimated trajectory %%%
    % Disagregating u into the time-steps of the model
    for j=1:(steps_horizon)
        idx = find(Control_Vector < j,1,'last'); % U disagregated into time-steps
        u(j,1) = U(idx);
    end
    previous_control = U(n_controls);    
    %%% Noise Generation - Application %%%
    % In case noise is generated in the states, you can model it by a
    % assuming a Gaussian noise with an average and variance specified
    % below (This applies only to the plant)
    average = 0.0; % average noise in (m)
    variance = 0; % variance in (m2). Remember that xbar - 2std has a prob of 93... %, std = sqrt(variance)
    
    %%% Reservoir Plant %%%
    [h_r,out_r] = plant_reservoir(Qout_w,time_step,u,h_r_t,ur_eq_t); % Reservoir Dynamics
    h_r_t = h_r(steps_control_horizon); ur_eq_t = U(n_controls); % Initial values for the next step
    %%% Channel Plant %%%
    [max_water_level,h_c,out_c] = plant_channel(out_r,time_step,h_c_0); % Channel Dynamics
    h_c_0 = h_c(:,steps_control_horizon); % Initial Values for the next step
    %%% Saving Results %%%
    h_r_final(time_begin:time_end_saving,1) = h_r(1:steps_control_horizon,1);
    our_r_final(time_begin:time_end_saving,1) = out_r(1:steps_control_horizon,1);
    h_c_final(:,(time_begin:time_end_saving)) = h_c(:,1:steps_control_horizon);
    out_c_final(time_begin:time_end_saving,1) = out_c(1:steps_control_horizon,1);
end
% Disagregating controls 
Control_Vector = [0:Control_Interval*60/time_step:n_steps];
for i=1:(n_steps-1)
    idx = find(Control_Vector < i,1,'last'); % Position in U
    u(i,1) = controls(idx);
end
u = [0;u];
u_final = u; % final results
graphs_wshed_reservoir_channel
display_results;

