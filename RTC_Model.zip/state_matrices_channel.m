%% State-Space Matrices for the Channel
% 8/1/2021
% Developer: Marcus Nobrega
% Goal - Define a model such that h(k+1) = A_chan*h(k) + gama_C for the channel
% segments
function [A_chan,fi_c,out_c] = state_matrices_channel(time_step,segments,gama_c,dir_matrix,x_cells,A_slope,B_slope,roughness,h_0_c,cell_area,outflow)
% Call Gradient Function
    [gradient_c] = gradient_channel(dir_matrix,x_cells,A_slope,B_slope,roughness,h_0_c,cell_area);
% Discretize the problem
    T = time_step;
    A_tilda_c = (eye(segments) + T*gradient_c);
    A_chan = A_tilda_c;
    fi_c = T*(gama_c - gradient_c*h_0_c); 
    slope = A_slope*h_0_c + B_slope;
    out_c = (outflow(h_0_c,x_cells,roughness,slope));
    out_c = out_c(segments,1);
end

