%% Reservoir State Space Matrices
% Developer - Marcus Nobrega
% 5/7/2021
% Goal - Define A_res, B_res and gama_res for the state-space
% representation
function [A_res, B_res,fi_res,out_r,outflow_eq,alfa,beta] = state_matrices_reservoir(Qin_rt,h_eq,u_eq,h_rt,time_step,alfa_1,alfa_2,beta_1,beta_2,i_0)
%% 1.0 - Parameters
clc
% Initial Values
h_t = h_rt; % Water Level in the Reservoir (m)
g = 9.81; % m/s^2
T = time_step; % seconds
% Reservoir Area
[Area_Function] = reservoir_area(0) ; % A = f(h) (handle) Function of h (to change, is required to change the function)
% Orifice Parameters
Cd = 0.68;
ho = 0.0; % Outlet water level (m)
number_of_orifices = 2;
%   Circular
flag_c = 1; % 1 if it is circular, 0 if not used
D = 1.2; % m
Aoc = pi()*D^2/4*number_of_orifices;
%   Rectangular
flag_r = 0; % 1 if it is rectangular, 0 if not used
l = 1; % m
b = 1.2; % m
Aor = l*b*number_of_orifices; % m2
if ((flag_c == 1) && (flag_r == 1))
    error('Please choose only one type of orifice')
elseif (flag_c == 1)
    D_h = D; % circular
    Ao = Aoc; % m2
else
    D_h = 4*(l*b)/(2*(l+b)); % rectangular
    Ao = Aor; % m2
end
hmin = 0.2; % minimum relative water depth
orifice_height = 0; % m from the bottom
h_flow = max(hmin*D_h,orifice_height);

% Spillway Parameters
Cds = 2.10;
Lef = 3; % m
hs = 5.5; % m
% Reservoir Porosity
porosity = 1;
% Flow Equation
outflow_eq = @(Ko,Ks,h,hs,ho) (Ko.*u_eq*sqrt(max(h - h_flow,0)) + max(Ks.*(h - hs),0).^(3/2));
%% 2.0 - Calculating Constants
Ko = Cd*Ao; Ks = Cds*Lef;
%% 3.0 Determining Jacobian Matrices
[alfa,beta] = alfabeta_matrices(Qin_rt,Ko,u_eq,h_eq,h_flow,Ks,hs,h_t,alfa_1,alfa_2,beta_1,beta_2,D_h);
% Calculating gama
gama = (1/(Area_Function(h_eq)*porosity)*(Qin_rt - outflow_eq(Ko,Ks,h_eq,hs,h_flow)) + i_0/1000/3600);
gama(isnan(gama))=0;
C = 1;
D = 0;
%% 4.0 -  Discretizing the System
A_res = (1 + T*alfa); % If there is more than 1 reservoir, it 1 -> eye
B_res = (T*beta);
fi_res = (T*gama - T*alfa*h_eq - T*beta*u_eq);
% h(k+1) = A_res*h(k) + B_res*u + fi(k)
%% 5.0 - Outflow 
out_r = outflow_eq(Ko,Ks,h_eq,hs,ho);
end